"""Partner worktree application package."""

