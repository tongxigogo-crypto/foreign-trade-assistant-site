from __future__ import annotations

APP_VERSION = "v0.1.1-beta1-build10"
