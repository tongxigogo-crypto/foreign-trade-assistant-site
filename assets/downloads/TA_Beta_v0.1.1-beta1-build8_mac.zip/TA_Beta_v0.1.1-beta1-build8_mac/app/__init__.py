"""Partner worktree application package."""

